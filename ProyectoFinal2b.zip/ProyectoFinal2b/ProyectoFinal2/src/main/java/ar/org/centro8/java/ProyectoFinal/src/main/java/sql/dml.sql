
use disqueria;
-- data manipulation lenguage 
-- registrar 5 datos por tabla al menos 
-- luego de terminar esto pensar las consultas de prueba.


insert into disco (id, album, artista, genero, anio , precio, tipodisco)
values (0, 'Bad Romance', 'Lady Gaga', 'Pop', 2009, 2500, 'CD'),
       (2, 'Prism', 'Katy Perry', 'Pop', 2013, 3400, 'CD'),
	   (3, 'Arrival', 'ABBA', 'Pop, Eurodisco', 1976, 5000, 'VINILO'),
	   (4, 'With Arms Wide Open:A Retrospective', 'Creed', 'HardRock', 2015, 4000, 'DVD'),
	   (5, 'Surrender', 'Rufus du sol', 'Electronica', 2021, 5000, 'CD'),
       (6, 'House of love', 'Kate Bush', 'Pop-rock' , 1985, 1200, 'CASSETE'),
       (7, 'True colors', 'Cindy Lauper', 'Dance-Pop', 1986, 1340, 'CASSETE'),
       (8, 'The Works', 'Queen', 'Pop-Rock', 1984, 1259,'CASSETE'),
	   (9, 'FireWork', 'Katy Perry', 'Pop-Rock', 1999, 2555, 'DVD');
	   


        
insert into sucursal(id, nombre, direccion, stock)
values (1, 'Medrano discos' , 'Medrano 164', 25000),
	   (2, 'Pueyrredon discos' , 'Jose cubas 2854', 15000),
	   (3, 'Palermo Hollywood discos' , 'Costa rica 4888', 150000),
	   (4, 'Abasto shopping discos' , 'av.Corrientes 3247', 120000),
	   (5, 'San Martin discos' , 'Intendente campos 58', 2500);

       
insert into cliente (id, nombre, apellido, edad, idSucursal)
values  (1, 'Juana', 'De arco', 34 , 2),
		(2, 'Mario', 'Bross', 30 , 3),
		(3, 'Marie', 'Curie', 43 , 4),
		(4, 'Stella', 'Artois', 20 , 5),
		(5, 'Jhonny', 'Depp', 58 , 2),
		(6, 'Amber', 'Heart', 55 , 1),
        (7, 'Pepa', 'Pig', 20, 3),
        (8, 'Bruce', 'Wayne', 35, 1),
        (9, 'Lois', 'Lane', 34, 1),
        (10, 'Cris','Morena', 56, 2);
       
insert into sucursalStock(id, idSucursal, idDisco, stock)
values (1, 1, 1,  10),
		(2, 5, 2,  54),
		(3, 4, 3, 55),
		(4, 3, 4, 300),
		(5, 5, 5, 58),
		(6, 2, 6,  500),
		(7, 1, 7,  150),
		(8, 3, 5,  100),
		(9, 4, 1,  5),
		(10, 4, 2,  10),
		(11, 4, 5,  100),
		(12, 2, 9, 0);






