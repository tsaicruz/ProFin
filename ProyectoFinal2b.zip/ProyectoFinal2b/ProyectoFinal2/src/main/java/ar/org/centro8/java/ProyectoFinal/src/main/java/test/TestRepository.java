package ar.org.centro8.java.ProyectoFinal.src.main.java.test;

import java.sql.Connection;

import ar.org.centro8.java.ProyectoFinal.src.main.java.connections.Connector;
import ar.org.centro8.java.ProyectoFinal.src.main.java.entities.Cliente;
import ar.org.centro8.java.ProyectoFinal.src.main.java.entities.Disco;
import ar.org.centro8.java.ProyectoFinal.src.main.java.entities.Sucursal;
import ar.org.centro8.java.ProyectoFinal.src.main.java.entities.SucursalStock;
import ar.org.centro8.java.ProyectoFinal.src.main.java.enums.Tipodisco;
import ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.interfaces.I_ClienteRepository;
import ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.interfaces.I_DiscoRepository;
import ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.interfaces.I_SucursalRepository;
import ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.interfaces.I_SucursalStockRepository;
import ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.jdbc.ClienteRepository;
import ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.jdbc.DiscoRepository;
import ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.jdbc.SucursalRepository;
import ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.jdbc.SucursalStockRepository;

public class TestRepository {
    public static void main(String[] args) {
        Connection conn = (Connection) Connector.getConnection();
        I_DiscoRepository disc = new DiscoRepository(conn);

        Disco disco = new Disco("PUM", "PIM", "POP", 1099, 1300, Tipodisco.VINILO);
        disc.save(disco);
        System.out.println(disco);
        disc.getAll().forEach(System.out::println);
        disc.remove(disc.getById(10));
        disco = disc.getById(8);
        disco.setTipodisco(Tipodisco.DVD);
        disc.update(disco);
        disc.getAll().forEach(System.out::println);
        System.out.println("*******************************************************************************");
        System.out.println("*************************************************************************************");
        disc.getLikeArtista("arr").forEach(System.out::println);

        System.out.println("*******************************************************************************");
        System.out.println("*************************************************************************************");

        I_ClienteRepository cl = new ClienteRepository(conn);
        Cliente cliente = new Cliente("Carlin", "Ga", 25, 5);
        cl.save(cliente);
        System.out.println(cliente);
        cl.getAll().forEach(System.out::println);
        cl.remove(cl.getById(11));
        cliente = cl.getById(3);
        cliente.setNombre("Marie");
        cl.update(cliente);
        cl.getAll().forEach(System.out::println);
        System.out.println("*******************************************************************************");
        System.out.println("*************************************************************************************");

        I_SucursalRepository sc = new SucursalRepository(conn);
        Sucursal sucursal = new Sucursal("Suquitruki", "Suculitas 1234", 0);
        sc.save(sucursal);
        // System.out.println(sucursal);
        sc.remove(sc.getById(6));
        sucursal = sc.getById(1);
        sucursal.setNombre("Hollywood discos");
        sc.update(sucursal);
        // sc.getAll().forEach(System.out::println);

        I_SucursalStockRepository ss = new SucursalStockRepository(conn);
        SucursalStock sucursalstock = new SucursalStock(8, 11, 10);
        ss.save(sucursalstock);
        System.out.println(sucursalstock);
        ss.remove(ss.getById(2));
        sucursalstock = ss.getById(4);
        sucursalstock.setIdDisco(5);
        ss.update(sucursalstock);

    }

}
