package ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.java.ProyectoFinal.src.main.java.entities.Disco;
import ar.org.centro8.java.ProyectoFinal.src.main.java.enums.Tipodisco;
import ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.interfaces.I_DiscoRepository;

public class DiscoRepository implements I_DiscoRepository {

    private Connection conn;

    public DiscoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Disco> getAll() {
        List<Disco> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from disco")) {
            while (rs.next()) {
                list.add(
                        new Disco(
                                rs.getInt("id"),
                                rs.getString("album"),
                                rs.getString("artista"),
                                rs.getString("genero"),
                                rs.getInt("anio"),
                                rs.getDouble("precio"),
                                Tipodisco.valueOf(rs.getString("tipodisco"))));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void remove(Disco disco) {
        if (disco == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from disco where id=?")) {
            ps.setInt(1, disco.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void save(Disco disco) {
        if (disco == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into disco (album,artista,genero,anio,precio,tipodisco) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, disco.getAlbum());
            ps.setString(2, disco.getArtista());
            ps.setString(3, disco.getGenero());
            ps.setInt(4, disco.getAnio());
            ps.setDouble(5, disco.getPrecio());
            ps.setString(6, disco.getTipodisco().toString());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                disco.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Disco disco) {
        if (disco == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update disco set album=?, artista=?, genero=?, anio=?, precio=?, tipodisco=? where id=?")) {
            ps.setString(1, disco.getAlbum());
            ps.setString(2, disco.getArtista());
            ps.setString(3, disco.getGenero());
            ps.setInt(4, disco.getAnio());
            ps.setDouble(5, disco.getPrecio());
            ps.setString(6, disco.getTipodisco().toString());
            ps.setInt(7, disco.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
