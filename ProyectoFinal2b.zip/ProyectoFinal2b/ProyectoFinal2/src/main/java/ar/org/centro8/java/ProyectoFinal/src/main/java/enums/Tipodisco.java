package ar.org.centro8.java.ProyectoFinal.src.main.java.enums;

public enum Tipodisco {
    VINILO,
    CD,
    DVD,
    CASSETE;
}
