package ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.interfaces;

import java.util.List;

import ar.org.centro8.java.ProyectoFinal.src.main.java.entities.SucursalStock;

public interface I_SucursalStockRepository {

    void save(SucursalStock sucursalstock);

    void remove(SucursalStock sucursalstock);

    void update(SucursalStock sucursalstock);

    default SucursalStock getById(int id) {
        return getAll()
                .stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(new SucursalStock());
    }

    List<SucursalStock> getAll();

}
