package ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.centro8.java.ProyectoFinal.src.main.java.entities.Cliente;

public interface I_ClienteRepository {

    void save(Cliente cliente);

    void remove(Cliente cliente);

    void update(Cliente cliente);

    default Cliente getById(int id) {
        return getAll()
                .stream()
                .filter(a -> a.getId() == id)
                .findFirst()
                .orElse(new Cliente());
    }

    List<Cliente> getAll();

    default List<Cliente> getLikeApellido(String apellido) {
        if (apellido == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getApellido() != null)
                .filter(a -> a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                .collect(Collectors.toList());
    }

}
