package ar.org.centro8.java.ProyectoFinal.src.main.java.repositorios.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.centro8.java.ProyectoFinal.src.main.java.entities.Disco;

public interface I_DiscoRepository {
    void save(Disco disco);

    void remove(Disco disco);

    void update(Disco disco);

    default Disco getById(int id) {
        return getAll()
                .stream()
                .filter(d -> d.getId() == id)
                .findFirst()
                .orElse(new Disco());
    }

    List<Disco> getAll();

    default List<Disco> getLikeArtista(String artista) {
        if (artista == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(d -> d.getArtista() != null)
                .filter(d -> d.getArtista().toLowerCase().contains(artista.toLowerCase()))
                .collect(Collectors.toList());
    }

}
